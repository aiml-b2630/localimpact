"""
AI Code Processing Engine (v2.0.0)
Calculates complexity, analyzes static metrics, generates AI improvements,
and simulates test suite execution.
"""

import math
import re
from datetime import datetime
from typing import List, Tuple
from models import CodeRecord, AIImprovement
from logger_config import logger

class AICodeEngine:
    @staticmethod
    def calculate_cyclomatic_complexity(code: str) -> float:
        if not code.strip():
            return 1.0
        # Count control flow keywords and logical operators
        keywords = r'\b(if|elif|else|for|while|except|with|assert|and|or|case|match)\b'
        matches = len(re.findall(keywords, code))
        # Base complexity is 1 + decision points
        lines = [line for line in code.splitlines() if line.strip() and not line.strip().startswith('#')]
        line_count = len(lines)
        density_factor = line_count / 30.0
        complexity = round(1.0 + matches * 0.85 + density_factor * 0.5, 2)
        return max(1.0, min(complexity, 25.0))

    @staticmethod
    def analyze_code(program_name: str, language: str, original_code: str) -> CodeRecord:
        logger.info(f"Analyzing code for program: {program_name} ({language})")
        lines = original_code.splitlines()
        loc = max(1, len([l for l in lines if l.strip()]))
        complexity = AICodeEngine.calculate_cyclomatic_complexity(original_code)

        # Generate AI Improvements based on static pattern checks
        improvements: List[AIImprovement] = []

        if "for " in original_code and "range(len(" in original_code:
            improvements.append(
                AIImprovement(
                    suggestion_id="SUG-01",
                    category="Readability",
                    title="Use enumerate() over index iteration",
                    description="Iterating with range(len()) is unidiomatic in Python. Use enumerate() for clean index-value pair iteration.",
                    original_snippet="for i in range(len(items)):\n    val = items[i]",
                    improved_snippet="for i, val in enumerate(items):\n    # process i and val",
                    impact_rating="Medium",
                )
            )

        if "open(" in original_code and "close()" in original_code and "with open" not in original_code:
            improvements.append(
                AIImprovement(
                    suggestion_id="SUG-02",
                    category="Resource Management",
                    title="Use Context Managers (with statement)",
                    description="Manual open/close can leak file descriptors on exceptions. Wrap file operations in a 'with' block.",
                    original_snippet="f = open('data.txt', 'r')\n# ops\nf.close()",
                    improved_snippet="with open('data.txt', 'r') as f:\n    # ops",
                    impact_rating="High",
                )
            )

        if "+" in original_code and "str(" in original_code:
            improvements.append(
                AIImprovement(
                    suggestion_id="SUG-03",
                    category="Performance",
                    title="Adopt F-Strings for string formatting",
                    description="String concatenation with '+' creates intermediate string objects. Formatted f-strings offer better performance and readability.",
                    original_snippet="msg = 'User ' + str(name) + ' has score ' + str(score)",
                    improved_snippet="msg = f'User {name} has score {score}'",
                    impact_rating="Low",
                )
            )

        # Default fallback suggestions if none matched specific patterns
        if not improvements:
            improvements.append(
                AIImprovement(
                    suggestion_id="SUG-10",
                    category="Refactoring",
                    title="Add Type Hints & Docstrings",
                    description="Annotating function parameters and return types improves IDE autocompletion and static type checking with mypy.",
                    original_snippet="def process_data(data, flag=False):",
                    improved_snippet="def process_data(data: list[dict], flag: bool = False) -> dict:",
                    impact_rating="Medium",
                )
            )
            improvements.append(
                AIImprovement(
                    suggestion_id="SUG-11",
                    category="Security",
                    title="Defensive Bounds & Exception Handling",
                    description="Wrap parsing and index access in explicit try-except blocks to prevent unhandled runtime errors.",
                    original_snippet="res = data[idx]",
                    improved_snippet="try:\n    res = data[idx]\nexcept IndexError:\n    res = None",
                    impact_rating="High",
                )
            )

        rec_id = f"REC-{hash(program_name + datetime.now().isoformat()) % 9000 + 1000}"
        summary = (
            f"Analyzed '{program_name}' ({loc} LOC, Complexity: {complexity}). "
            f"AI identified {len(improvements)} actionable optimizations across {', '.join(set(i.category for i in improvements))}."
        )

        exec_time = round(12.5 + loc * 0.45 + complexity * 1.2, 2)
        mem_usage = round(4.2 + loc * 0.08, 2)

        return CodeRecord(
            record_id=rec_id,
            program_name=program_name,
            language=language,
            lines_of_code=loc,
            cyclomatic_complexity=complexity,
            status="Analyzed",
            created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            original_code=original_code,
            ai_summary=summary,
            ai_improvements=improvements,
            execution_time_ms=exec_time,
            memory_mb=mem_usage,
        )
