"""
Unit Tests for Analytics & Threshold Warnings
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from analytics import AnalyticsModule
from models import CodeRecord

class TestAnalyticsModule(unittest.TestCase):
    def test_empty_dataset_analytics(self):
        metrics = AnalyticsModule.compute_summary([])
        self.assertEqual(metrics.total_records, 0)
        self.assertEqual(metrics.avg_complexity, 0.0)
        self.assertIn("empty", metrics.threshold_warnings[0].lower())

    def test_threshold_warning_trigger(self):
        r1 = CodeRecord("R1", "P1", "Python", 100, 3.0, "Analyzed", "2026-11-22", "", "")
        r2 = CodeRecord("R2", "P2", "Python", 600, 8.5, "Analyzed", "2026-11-22", "", "") # Trigger high complexity & loc

        metrics = AnalyticsModule.compute_summary([r1, r2])
        self.assertEqual(metrics.total_records, 2)
        self.assertEqual(metrics.avg_complexity, 5.75)
        self.assertGreaterEqual(len(metrics.threshold_warnings), 2)

if __name__ == "__main__":
    unittest.main()
