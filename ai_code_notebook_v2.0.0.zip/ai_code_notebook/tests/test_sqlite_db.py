"""
Unit Tests for SQLite Database & Pagination
"""

import sys
import os
import unittest
import tempfile

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sqlite_db import SQLiteDatabase
from models import CodeRecord, AIImprovement

class TestSQLiteDatabase(unittest.TestCase):
    def setUp(self):
        self.temp_db_fd, self.temp_db_path = tempfile.mkstemp(suffix=".db")
        self.db = SQLiteDatabase(self.temp_db_path)

    def tearDown(self):
        os.close(self.temp_db_fd)
        if os.path.exists(self.temp_db_path):
            os.remove(self.temp_db_path)

    def test_save_and_get_record(self):
        imp = AIImprovement("SUG-01", "Performance", "Opt 1", "Desc", "a=1", "a=2", "High")
        rec = CodeRecord("REC-TEST-1", "TestProg", "Python", 50, 4.2, "Analyzed", "2026-11-22 10:00:00", "code", "summary", [imp])

        saved = self.db.save_record(rec)
        self.assertTrue(saved)

        fetched = self.db.get_record("REC-TEST-1")
        self.assertIsNotNone(fetched)
        self.assertEqual(fetched.program_name, "TestProg")
        self.assertEqual(len(fetched.ai_improvements), 1)
        self.assertEqual(fetched.ai_improvements[0].suggestion_id, "SUG-01")

    def test_pagination_and_querying(self):
        records = []
        for i in range(25):
            rec = CodeRecord(f"REC-PAG-{i}", f"Prog_{i}", "Python" if i % 2 == 0 else "Go", 10 + i, 2.0 + (i * 0.2), "Analyzed", f"2026-11-22 10:{i:02d}:00", "code", "summary")
            records.append(rec)

        self.db.save_records_batch(records)

        # Page 1, size 10
        page1 = self.db.query_records_paginated(page=1, page_size=10)
        self.assertEqual(len(page1.items), 10)
        self.assertEqual(page1.total_count, 25)
        self.assertEqual(page1.total_pages, 3)

        # Filter by language
        go_records = self.db.query_records_paginated(language="Go", page=1, page_size=50)
        self.assertEqual(go_records.total_count, 12)

    def test_delete_record(self):
        rec = CodeRecord("REC-DEL", "ToDelete", "Python", 10, 1.0, "Draft", "2026-11-22", "", "")
        self.db.save_record(rec)

        deleted = self.db.delete_record("REC-DEL")
        self.assertTrue(deleted)

        fetched = self.db.get_record("REC-DEL")
        self.assertIsNone(fetched)

if __name__ == "__main__":
    unittest.main()
