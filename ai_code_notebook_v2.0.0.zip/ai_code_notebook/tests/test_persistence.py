"""
Unit Tests for Persistence Manager & Atomic File IO
"""

import sys
import os
import unittest
import tempfile

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from persistence import PersistenceManager
from sqlite_db import SQLiteDatabase
from models import CodeRecord

class TestPersistenceManager(unittest.TestCase):
    def setUp(self):
        self.temp_db_fd, self.temp_db_path = tempfile.mkstemp(suffix=".db")
        self.db = SQLiteDatabase(self.temp_db_path)
        self.pm = PersistenceManager(self.db)

    def tearDown(self):
        os.close(self.temp_db_fd)
        if os.path.exists(self.temp_db_path):
            os.remove(self.temp_db_path)

    def test_save_and_load_records(self):
        rec = CodeRecord("REC-PM-TEST", "PMTest", "Rust", 120, 3.5, "Analyzed", "2026-11-22 10:00:00", "code", "summary")
        success = self.pm.save_record(rec)
        self.assertTrue(success)

        fetched = self.db.get_record("REC-PM-TEST")
        self.assertIsNotNone(fetched)
        self.assertEqual(fetched.record_id, "REC-PM-TEST")

if __name__ == "__main__":
    unittest.main()
