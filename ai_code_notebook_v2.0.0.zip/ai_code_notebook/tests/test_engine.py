"""
Unit Tests for AI Code Processing Engine
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engine import AICodeEngine
from models import CodeRecord

class TestAICodeEngine(unittest.TestCase):
    def test_cyclomatic_complexity_empty_code(self):
        complexity = AICodeEngine.calculate_cyclomatic_complexity("")
        self.assertEqual(complexity, 1.0)

    def test_cyclomatic_complexity_control_flow(self):
        code = (
            "def check_values(items):\n"
            "    if not items:\n"
            "        return None\n"
            "    for item in items:\n"
            "        if item > 10 and item < 50:\n"
            "            print(item)\n"
            "        elif item == 100:\n"
            "            break\n"
            "        else:\n"
            "            continue\n"
        )
        complexity = AICodeEngine.calculate_cyclomatic_complexity(code)
        self.assertGreater(complexity, 3.0)

    def test_analyze_code_pattern_matching(self):
        code = (
            "for i in range(len(data)):\n"
            "    v = data[i]\n"
            "    f = open('test.txt', 'r')\n"
            "    f.close()\n"
        )
        record = AICodeEngine.analyze_code("PatternTest", "Python", code)

        self.assertIsInstance(record, CodeRecord)
        self.assertEqual(record.program_name, "PatternTest")
        self.assertGreater(len(record.ai_improvements), 0)

        categories = [imp.category for imp in record.ai_improvements]
        self.assertIn("Readability", categories)
        self.assertIn("Resource Management", categories)

if __name__ == "__main__":
    unittest.main()
