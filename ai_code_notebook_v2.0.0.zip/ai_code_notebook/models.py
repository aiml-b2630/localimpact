"""
Data Models Module (v2.0.0)
Defines structured dataclasses representing code explanation records,
AI optimization suggestions, summary metrics, and pagination structures.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Any, Optional

@dataclass
class AIImprovement:
    suggestion_id: str
    category: str  # e.g., 'Performance', 'Readability', 'Security', 'Refactoring'
    title: str
    description: str
    original_snippet: str
    improved_snippet: str
    impact_rating: str  # 'Low', 'Medium', 'High', 'Critical'

@dataclass
class CodeRecord:
    record_id: str
    program_name: str
    language: str
    lines_of_code: int
    cyclomatic_complexity: float
    status: str  # 'Draft', 'Analyzed', 'Optimized', 'Archived'
    created_at: str
    original_code: str
    ai_summary: str
    ai_improvements: List[AIImprovement] = field(default_factory=list)
    execution_time_ms: float = 0.0
    memory_mb: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "record_id": self.record_id,
            "program_name": self.program_name,
            "language": self.language,
            "lines_of_code": self.lines_of_code,
            "cyclomatic_complexity": self.cyclomatic_complexity,
            "status": self.status,
            "created_at": self.created_at,
            "original_code": self.original_code,
            "ai_summary": self.ai_summary,
            "execution_time_ms": self.execution_time_ms,
            "memory_mb": self.memory_mb,
            "ai_improvements": [
                {
                    "suggestion_id": imp.suggestion_id,
                    "category": imp.category,
                    "title": imp.title,
                    "description": imp.description,
                    "original_snippet": imp.original_snippet,
                    "improved_snippet": imp.improved_snippet,
                    "impact_rating": imp.impact_rating,
                }
                for imp in self.ai_improvements
            ],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CodeRecord":
        improvements = [
            AIImprovement(**imp) for imp in data.get("ai_improvements", [])
        ]
        return cls(
            record_id=data["record_id"],
            program_name=data["program_name"],
            language=data.get("language", "Python"),
            lines_of_code=data.get("lines_of_code", 0),
            cyclomatic_complexity=float(data.get("cyclomatic_complexity", 1.0)),
            status=data.get("status", "Analyzed"),
            created_at=data.get("created_at", datetime.now().isoformat()),
            original_code=data.get("original_code", ""),
            ai_summary=data.get("ai_summary", ""),
            execution_time_ms=float(data.get("execution_time_ms", 0.0)),
            memory_mb=float(data.get("memory_mb", 0.0)),
            ai_improvements=improvements,
        )

@dataclass
class SummaryMetrics:
    total_records: int
    total_lines_of_code: int
    avg_complexity: float
    avg_execution_time_ms: float
    status_counts: Dict[str, int]
    language_counts: Dict[str, int]
    category_counts: Dict[str, int]
    threshold_warnings: List[str]

@dataclass
class PaginatedResult:
    items: List[CodeRecord]
    total_count: int
    page: int
    page_size: int
    total_pages: int
