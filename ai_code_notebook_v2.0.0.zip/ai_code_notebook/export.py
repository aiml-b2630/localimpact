"""
Multi-Format Async Exporter Module (v2.0.0 Enhancement)
Executes export workflows asynchronously using concurrent thread pools to keep
the CLI interface responsive during disk I/O and Matplotlib chart rendering.
"""

import os
import concurrent.futures
from datetime import datetime
from typing import List, Dict, Any, Tuple
from models import CodeRecord, SummaryMetrics
from analytics import AnalyticsModule
from plotting import VisualPlotter
from logger_config import logger

REPORT_DIR = os.path.join(os.path.dirname(__file__), "reports")
os.makedirs(REPORT_DIR, exist_ok=True)

class AsyncExporter:
    @staticmethod
    def _export_markdown_task(records: List[CodeRecord], metrics: SummaryMetrics, filepath: str) -> str:
        content = [
            "# Executive Summary Report — AI Code Explanation Notebook",
            f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ",
            f"**Total Programs Analyzed:** {metrics.total_records}  ",
            f"**Total Lines of Code:** {metrics.total_lines_of_code}  ",
            f"**Average Cyclomatic Complexity:** {metrics.avg_complexity} / 10.0  ",
            f"**Average Execution Time:** {metrics.avg_execution_time_ms} ms  ",
            "\n---",
            "\n## Language Distribution",
        ]

        for lang, count in metrics.language_counts.items():
            content.append(f"- **{lang}:** {count} programs")

        content.append("\n## AI Suggestion Category Distribution")
        for cat, count in metrics.category_counts.items():
            content.append(f"- **{cat}:** {count} suggestions")

        content.append("\n## Threshold Warnings")
        if metrics.threshold_warnings:
            for w in metrics.threshold_warnings:
                content.append(f"- {w}")
        else:
            content.append("- *No critical threshold warnings detected.*")

        content.append("\n## Analyzed Records Summary Table\n")
        content.append("| Record ID | Program Name | Language | LOC | Complexity | Status | AI Suggestions |")
        content.append("|---|---|---|---|---|---|---|")

        for r in records:
            content.append(
                f"| {r.record_id} | {r.program_name} | {r.language} | {r.lines_of_code} | "
                f"{r.cyclomatic_complexity} | {r.status} | {len(r.ai_improvements)} |"
            )

        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(content))

        logger.info(f"Markdown report generated: {filepath}")
        return filepath

    @staticmethod
    def _export_audit_log_task(records: List[CodeRecord], filepath: str) -> str:
        lines = [
            "========================================================================",
            "AI CODE EXPLANATION NOTEBOOK — SYSTEM AUDIT LOG",
            f"Export Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Total Records Logged: {len(records)}",
            "========================================================================",
            ""
        ]

        for r in records:
            lines.append(f"[{r.created_at}] RECORD {r.record_id} | {r.program_name} ({r.language})")
            lines.append(f"  - LOC: {r.lines_of_code} | Complexity: {r.cyclomatic_complexity} | Status: {r.status}")
            lines.append(f"  - AI Summary: {r.ai_summary}")
            for imp in r.ai_improvements:
                lines.append(f"    * [{imp.impact_rating.upper()}] {imp.category}: {imp.title}")
            lines.append("-" * 72)

        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        logger.info(f"Audit log generated: {filepath}")
        return filepath

    @classmethod
    def export_all_async(cls, records: List[CodeRecord]) -> Dict[str, str]:
        """Runs Markdown report, audit log, and Matplotlib plotting in parallel workers."""
        logger.info(f"Starting async export worker pool for {len(records)} records...")
        metrics = AnalyticsModule.compute_summary(records)

        md_path = os.path.join(REPORT_DIR, "executive_summary.md")
        log_path = os.path.join(REPORT_DIR, "audit_log.txt")
        chart_path = os.path.join(REPORT_DIR, "analytics_dashboard.png")

        results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
            future_md = executor.submit(cls._export_markdown_task, records, metrics, md_path)
            future_log = executor.submit(cls._export_audit_log_task, records, log_path)
            future_chart = executor.submit(VisualPlotter.generate_dashboard, records, metrics, chart_path)

            results["markdown"] = future_md.result()
            results["audit_log"] = future_log.result()
            results["dashboard"] = future_chart.result()

        logger.info("Async export tasks completed successfully.")
        return results
