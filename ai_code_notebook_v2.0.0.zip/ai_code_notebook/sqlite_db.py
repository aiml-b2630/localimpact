"""
SQLite Database Engine (v2.0.0 Enhancement)
Provides transactional ACID persistence, structured table schemas,
indexing for fast O(log N) lookups, and built-in pagination support.
"""

import sqlite3
import json
import os
import threading
from typing import List, Optional, Tuple, Dict, Any
from models import CodeRecord, AIImprovement, PaginatedResult
from logger_config import logger

DB_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DB_DIR, exist_ok=True)
DB_PATH = os.path.join(DB_DIR, "app_database.db")

class SQLiteDatabase:
    _lock = threading.Lock()

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self.init_db()

    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def init_db(self):
        with self._lock:
            logger.info(f"Initializing SQLite database schema at: {self.db_path}")
            conn = self.get_connection()
            try:
                cursor = conn.cursor()
                cursor.execute("""
                CREATE TABLE IF NOT EXISTS records (
                    record_id TEXT PRIMARY KEY,
                    program_name TEXT NOT NULL,
                    language TEXT NOT NULL,
                    lines_of_code INTEGER NOT NULL,
                    cyclomatic_complexity REAL NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    original_code TEXT,
                    ai_summary TEXT,
                    execution_time_ms REAL DEFAULT 0.0,
                    memory_mb REAL DEFAULT 0.0
                );
                """)

                cursor.execute("""
                CREATE TABLE IF NOT EXISTS improvements (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    record_id TEXT NOT NULL,
                    suggestion_id TEXT NOT NULL,
                    category TEXT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    original_snippet TEXT,
                    improved_snippet TEXT,
                    impact_rating TEXT NOT NULL,
                    FOREIGN KEY (record_id) REFERENCES records (record_id) ON DELETE CASCADE
                );
                """)

                # Performance Indexing for fast scalable queries
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_records_language ON records(language);")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_records_complexity ON records(cyclomatic_complexity);")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_records_status ON records(status);")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_records_created_at ON records(created_at);")

                conn.commit()
            except Exception as e:
                conn.rollback()
                logger.error(f"Failed to initialize SQLite database: {e}")
                raise
            finally:
                conn.close()

    def save_record(self, record: CodeRecord) -> bool:
        with self._lock:
            conn = self.get_connection()
            try:
                cursor = conn.cursor()
                cursor.execute("""
                INSERT OR REPLACE INTO records (
                    record_id, program_name, language, lines_of_code,
                    cyclomatic_complexity, status, created_at, original_code,
                    ai_summary, execution_time_ms, memory_mb
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """, (
                    record.record_id, record.program_name, record.language,
                    record.lines_of_code, record.cyclomatic_complexity,
                    record.status, record.created_at, record.original_code,
                    record.ai_summary, record.execution_time_ms, record.memory_mb
                ))

                cursor.execute("DELETE FROM improvements WHERE record_id = ?;", (record.record_id,))
                for imp in record.ai_improvements:
                    cursor.execute("""
                    INSERT INTO improvements (
                        record_id, suggestion_id, category, title, description,
                        original_snippet, improved_snippet, impact_rating
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                    """, (
                        record.record_id, imp.suggestion_id, imp.category,
                        imp.title, imp.description, imp.original_snippet,
                        imp.improved_snippet, imp.impact_rating
                    ))

                conn.commit()
                logger.info(f"SQLite transaction committed for record {record.record_id}")
                return True
            except Exception as e:
                conn.rollback()
                logger.error(f"Error saving record {record.record_id} to SQLite: {e}")
                return False
            finally:
                conn.close()

    def save_records_batch(self, records: List[CodeRecord]) -> bool:
        with self._lock:
            conn = self.get_connection()
            try:
                cursor = conn.cursor()
                for rec in records:
                    cursor.execute("""
                    INSERT OR REPLACE INTO records (
                        record_id, program_name, language, lines_of_code,
                        cyclomatic_complexity, status, created_at, original_code,
                        ai_summary, execution_time_ms, memory_mb
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                    """, (
                        rec.record_id, rec.program_name, rec.language,
                        rec.lines_of_code, rec.cyclomatic_complexity,
                        rec.status, rec.created_at, rec.original_code,
                        rec.ai_summary, rec.execution_time_ms, rec.memory_mb
                    ))
                    cursor.execute("DELETE FROM improvements WHERE record_id = ?;", (rec.record_id,))
                    for imp in rec.ai_improvements:
                        cursor.execute("""
                        INSERT INTO improvements (
                            record_id, suggestion_id, category, title, description,
                            original_snippet, improved_snippet, impact_rating
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                        """, (
                            rec.record_id, imp.suggestion_id, imp.category,
                            imp.title, imp.description, imp.original_snippet,
                            imp.improved_snippet, imp.impact_rating
                        ))
                conn.commit()
                logger.info(f"Batch inserted {len(records)} records into SQLite")
                return True
            except Exception as e:
                conn.rollback()
                logger.error(f"Failed batch insert to SQLite: {e}")
                return False
            finally:
                conn.close()

    def get_record(self, record_id: str) -> Optional[CodeRecord]:
        conn = self.get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM records WHERE record_id = ?;", (record_id,))
            row = cursor.fetchone()
            if not row:
                return None
            return self._row_to_record(cursor, row)
        finally:
            conn.close()

    def delete_record(self, record_id: str) -> bool:
        with self._lock:
            conn = self.get_connection()
            try:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM records WHERE record_id = ?;", (record_id,))
                conn.commit()
                return cursor.rowcount > 0
            except Exception as e:
                conn.rollback()
                logger.error(f"Error deleting record {record_id}: {e}")
                return False
            finally:
                conn.close()

    def query_records_paginated(
        self,
        keyword: str = "",
        language: str = "",
        status: str = "",
        min_complexity: float = 0.0,
        max_complexity: float = 100.0,
        page: int = 1,
        page_size: int = 10
    ) -> PaginatedResult:
        conn = self.get_connection()
        try:
            cursor = conn.cursor()
            where_clauses = ["cyclomatic_complexity >= ?", "cyclomatic_complexity <= ?"]
            params: List[Any] = [min_complexity, max_complexity]

            if keyword:
                where_clauses.append("(program_name LIKE ? OR ai_summary LIKE ? OR original_code LIKE ?)")
                kw = f"%{keyword}%"
                params.extend([kw, kw, kw])

            if language:
                where_clauses.append("language = ?")
                params.append(language)

            if status:
                where_clauses.append("status = ?")
                params.append(status)

            where_str = " WHERE " + " AND ".join(where_clauses)

            # Count total matching records
            count_sql = f"SELECT COUNT(*) FROM records{where_str};"
            cursor.execute(count_sql, params)
            total_count = cursor.fetchone()[0]

            total_pages = max(1, (total_count + page_size - 1) // page_size)
            page = max(1, min(page, total_pages))
            offset = (page - 1) * page_size

            select_sql = f"SELECT * FROM records{where_str} ORDER BY created_at DESC LIMIT ? OFFSET ?;"
            query_params = params + [page_size, offset]
            cursor.execute(select_sql, query_params)
            rows = cursor.fetchall()

            records = [self._row_to_record(cursor, r) for r in rows]

            return PaginatedResult(
                items=records,
                total_count=total_count,
                page=page,
                page_size=page_size,
                total_pages=total_pages
            )
        finally:
            conn.close()

    def get_all_records(self) -> List[CodeRecord]:
        res = self.query_records_paginated(page=1, page_size=10000)
        return res.items

    def _row_to_record(self, cursor: sqlite3.Cursor, row: sqlite3.Row) -> CodeRecord:
        rec_id = row["record_id"]
        # Fetch associated improvements
        sub_cursor = cursor.connection.cursor()
        sub_cursor.execute("SELECT * FROM improvements WHERE record_id = ?;", (rec_id,))
        imp_rows = sub_cursor.fetchall()

        improvements = [
            AIImprovement(
                suggestion_id=ir["suggestion_id"],
                category=ir["category"],
                title=ir["title"],
                description=ir["description"],
                original_snippet=ir["original_snippet"],
                improved_snippet=ir["improved_snippet"],
                impact_rating=ir["impact_rating"]
            )
            for ir in imp_rows
        ]

        return CodeRecord(
            record_id=row["record_id"],
            program_name=row["program_name"],
            language=row["language"],
            lines_of_code=row["lines_of_code"],
            cyclomatic_complexity=row["cyclomatic_complexity"],
            status=row["status"],
            created_at=row["created_at"],
            original_code=row["original_code"],
            ai_summary=row["ai_summary"],
            execution_time_ms=row["execution_time_ms"],
            memory_mb=row["memory_mb"],
            ai_improvements=improvements
        )
