"""
Executive Analytics & Reporting Module (v2.0.0)
Aggregates performance metrics, computes complexity averages, language distributions,
and flags automated threshold warnings for overdue or critical code breaches.
"""

from typing import List, Dict, Any
from models import CodeRecord, SummaryMetrics
from logger_config import logger

class AnalyticsModule:
    @staticmethod
    def compute_summary(records: List[CodeRecord]) -> SummaryMetrics:
        if not records:
            logger.warning("Analytics computed on empty record list.")
            return SummaryMetrics(
                total_records=0,
                total_lines_of_code=0,
                avg_complexity=0.0,
                avg_execution_time_ms=0.0,
                status_counts={},
                language_counts={},
                category_counts={},
                threshold_warnings=["⚠️ Dataset is empty. No records to analyze."]
            )

        total_loc = sum(r.lines_of_code for r in records)
        avg_comp = round(sum(r.cyclomatic_complexity for r in records) / len(records), 2)
        avg_exec = round(sum(r.execution_time_ms for r in records) / len(records), 2)

        status_counts: Dict[str, int] = {}
        lang_counts: Dict[str, int] = {}
        category_counts: Dict[str, int] = {}
        warnings: List[str] = []

        for r in records:
            status_counts[r.status] = status_counts.get(r.status, 0) + 1
            lang_counts[r.language] = lang_counts.get(r.language, 0) + 1

            for imp in r.ai_improvements:
                category_counts[imp.category] = category_counts.get(imp.category, 0) + 1

            # Threshold Warnings
            if r.cyclomatic_complexity >= 7.0:
                warnings.append(
                    f"⚠️ [HIGH COMPLEXITY] {r.record_id} ({r.program_name}): "
                    f"Cyclomatic score {r.cyclomatic_complexity} exceeds threshold (7.0)."
                )
            if r.lines_of_code > 500:
                warnings.append(
                    f"⚠️ [LARGE FILE] {r.record_id} ({r.program_name}): "
                    f"{r.lines_of_code} LOC requires module decomposition."
                )

        logger.info(f"Analytics compiled for {len(records)} records. Generated {len(warnings)} threshold warnings.")

        return SummaryMetrics(
            total_records=len(records),
            total_lines_of_code=total_loc,
            avg_complexity=avg_comp,
            avg_execution_time_ms=avg_exec,
            status_counts=status_counts,
            language_counts=lang_counts,
            category_counts=category_counts,
            threshold_warnings=warnings
        )
