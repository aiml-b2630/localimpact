"""
Sample Dataset Seeder (v2.0.0)
Populates 40 realistic hackathon records covering diverse Python & polyglot codebases,
normal values, edge conditions, and boundary scores.
"""

import os
import random
from datetime import datetime, timedelta
from models import CodeRecord, AIImprovement
from engine import AICodeEngine
from persistence import PersistenceManager
from sqlite_db import SQLiteDatabase
from logger_config import logger

PROGRAM_NAMES = [
    "DataPipelineIngest", "AuthTokenValidator", "SQLQueryOptimizer",
    "CSVStreamParser", "AsyncHTTPFetcher", "BinarySearchTree",
    "MatrixMultiplier", "MemoryCacheLRU", "JWTDecoderUtility",
    "FileCompressorZip", "WebScraperSpider", "NeuralNetLayer",
    "KafkaEventConsumer", "RedisConnectionPool", "GraphShortestPath",
    "ConfigParserYAML", "RateLimiterTokenBucket", "ImageResizerPIL",
    "PasswordHasherBcrypt", "GraphQLSchemaBuilder"
]

LANGUAGES = ["Python", "Python", "Python", "TypeScript", "Go", "Rust"]

def generate_sample_dataset(count: int = 40) -> list[CodeRecord]:
    random.seed(42)
    records = []
    base_time = datetime.now() - timedelta(days=15)

    code_templates = [
        "def process_data(items):\n    for i in range(len(items)):\n        val = items[i]\n        if val > 10:\n            print(val)",
        "def read_file(path):\n    f = open(path, 'r')\n    data = f.read()\n    f.close()\n    return data",
        "def compute_score(name, score):\n    msg = 'User ' + str(name) + ' has score ' + str(score)\n    return msg",
        "def calculate_total(prices):\n    total = 0\n    for p in prices:\n        if p > 0:\n            total += p\n    return total",
        "class CacheLRU:\n    def __init__(self, capacity):\n        self.cap = capacity\n        self.map = {}\n    def get(self, key):\n        return self.map.get(key, -1)",
        "# Complex module\ndef execute_query(sql, params):\n    if not sql:\n        return None\n    for p in params:\n        if p is None:\n            raise ValueError('Null param')\n    return 'Success'"
    ]

    for i in range(count):
        prog = f"{random.choice(PROGRAM_NAMES)}_{i+1}"
        lang = random.choice(LANGUAGES)
        code = random.choice(code_templates) + f"\n# Additional logic iteration {i}"

        rec = AICodeEngine.analyze_code(prog, lang, code)
        rec.record_id = f"REC-10{i+1:02d}"
        rec.created_at = (base_time + timedelta(hours=i * 9)).strftime("%Y-%m-%d %H:%M:%S")

        if i % 7 == 0:
            rec.cyclomatic_complexity = round(7.2 + (i * 0.15), 2)
            rec.lines_of_code = 450 + i * 15
        elif i % 11 == 0:
            rec.status = "Draft"
        elif i % 5 == 0:
            rec.status = "Optimized"

        records.append(rec)

    return records

if __name__ == "__main__":
    records = generate_sample_dataset(40)
    db = SQLiteDatabase()
    pm = PersistenceManager(db)
    pm.save_records(records)
    print(f"Successfully generated {len(records)} sample records across SQLite, JSON, and CSV.")
