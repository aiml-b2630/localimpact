"""
Matplotlib Visualization Module (v2.0.0)
Generates high-resolution dashboard graphics depicting trends, language distribution,
and complexity vs execution time scatter plots.
"""

import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from typing import List
from models import CodeRecord, SummaryMetrics
from logger_config import logger

REPORT_DIR = os.path.join(os.path.dirname(__file__), "reports")
os.makedirs(REPORT_DIR, exist_ok=True)
CHART_PATH = os.path.join(REPORT_DIR, "analytics_dashboard.png")

class VisualPlotter:
    @staticmethod
    def generate_dashboard(records: List[CodeRecord], metrics: SummaryMetrics, output_path: str = CHART_PATH) -> str:
        if not records:
            logger.warning("VisualPlotter called with empty dataset; skipping plot generation.")
            return ""

        logger.info(f"Generating Matplotlib analytics chart dashboard at: {output_path}")

        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        fig.suptitle("AI Code Explanation Notebook — Executive Analytics Dashboard", fontsize=16, fontweight='bold', y=0.98)

        # 1. Cyclomatic Complexity Distribution (Histogram)
        ax1 = axes[0, 0]
        complexities = [r.cyclomatic_complexity for r in records]
        ax1.hist(complexities, bins=8, color='#3498db', edgecolor='black', alpha=0.8)
        ax1.set_title("Cyclomatic Complexity Distribution", fontsize=12, fontweight='bold')
        ax1.set_xlabel("Complexity Score")
        ax1.set_ylabel("Number of Programs")
        ax1.axvline(7.0, color='red', linestyle='--', label='Warning Threshold (7.0)')
        ax1.legend()
        ax1.grid(True, linestyle=':', alpha=0.6)

        # 2. Programming Language Distribution (Pie Chart)
        ax2 = axes[0, 1]
        langs = list(metrics.language_counts.keys())
        counts = list(metrics.language_counts.values())
        colors = ['#2ecc71', '#e74c3c', '#f1c40f', '#9b59b6', '#34495e', '#1abc9c']
        ax2.pie(counts, labels=langs, autopct='%1.1f%%', startangle=140, colors=colors[:len(langs)])
        ax2.set_title("Language Breakdown", fontsize=12, fontweight='bold')

        # 3. Complexity vs Execution Time (Scatter Plot)
        ax3 = axes[1, 0]
        exec_times = [r.execution_time_ms for r in records]
        locs = [r.lines_of_code for r in records]
        scatter = ax3.scatter(complexities, exec_times, c=locs, cmap='viridis', s=80, alpha=0.85, edgecolors='black')
        ax3.set_title("Complexity vs Execution Time (ms)", fontsize=12, fontweight='bold')
        ax3.set_xlabel("Cyclomatic Complexity")
        ax3.set_ylabel("Execution Time (ms)")
        cbar = fig.colorbar(scatter, ax=ax3)
        cbar.set_label("Lines of Code (LOC)")
        ax3.grid(True, linestyle=':', alpha=0.6)

        # 4. Improvement Category Frequency (Bar Chart)
        ax4 = axes[1, 1]
        cats = list(metrics.category_counts.keys())
        cat_counts = list(metrics.category_counts.values())
        ax4.barh(cats, cat_counts, color='#e67e22', edgecolor='black', alpha=0.85)
        ax4.set_title("AI Suggestion Categories", fontsize=12, fontweight='bold')
        ax4.set_xlabel("Count")
        ax4.grid(True, linestyle=':', alpha=0.6)

        plt.tight_layout(rect=[0, 0, 1, 0.95])
        plt.savefig(output_path, dpi=200, bbox_inches='tight')
        plt.close(fig)

        logger.info("Dashboard image successfully saved.")
        return output_path
