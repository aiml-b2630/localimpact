"""
Input Validation Module (v2.0.0)
Provides robust input sanitization, type conversion, regex checks,
and logging for CLI and program interactions.
"""

import re
from typing import Optional, List
from logger_config import logger

def validate_string(prompt: str, min_len: int = 1, max_len: int = 500, allow_empty: bool = False) -> str:
    while True:
        try:
            val = input(prompt).strip()
            if not val and allow_empty:
                return ""
            if len(val) < min_len:
                print(f"\033[91m[Error] Input must be at least {min_len} characters long.\033[0m")
                logger.warning(f"Validation failure: input shorter than {min_len} chars")
                continue
            if len(val) > max_len:
                print(f"\033[91m[Error] Input must not exceed {max_len} characters.\033[0m")
                logger.warning(f"Validation failure: input exceeds {max_len} chars")
                continue
            return val
        except (KeyboardInterrupt, EOFError):
            logger.info("User interrupted input stream")
            raise

def validate_integer(prompt: str, min_val: int = 1, max_val: int = 100000) -> int:
    while True:
        try:
            raw = input(prompt).strip()
            val = int(raw)
            if val < min_val or val > max_val:
                print(f"\033[91m[Error] Value must be between {min_val} and {max_val}.\033[0m")
                logger.warning(f"Integer out of range: {val} not in [{min_val}, {max_val}]")
                continue
            return val
        except ValueError:
            print("\033[91m[Error] Invalid input. Please enter a valid integer.\033[0m")
            logger.warning(f"Invalid integer string entered")

def validate_float(prompt: str, min_val: float = 0.0, max_val: float = 1000.0) -> float:
    while True:
        try:
            raw = input(prompt).strip()
            val = float(raw)
            if val < min_val or val > max_val:
                print(f"\033[91m[Error] Value must be between {min_val} and {max_val}.\033[0m")
                logger.warning(f"Float out of range: {val} not in [{min_val}, {max_val}]")
                continue
            return val
        except ValueError:
            print("\033[91m[Error] Invalid input. Please enter a valid decimal number.\033[0m")

def validate_choice(prompt: str, valid_choices: List[str]) -> str:
    choices_str = "/".join(valid_choices)
    choices_lower = [c.lower() for c in valid_choices]
    while True:
        try:
            val = input(f"{prompt} ({choices_str}): ").strip().lower()
            if val in choices_lower:
                idx = choices_lower.index(val)
                return valid_choices[idx]
            print(f"\033[91m[Error] Please choose one of: {choices_str}\033[0m")
        except (KeyboardInterrupt, EOFError):
            raise
