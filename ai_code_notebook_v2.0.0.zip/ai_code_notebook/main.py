"""
Main CLI Application Dispatcher (v2.0.0 Release)
Provides interactive terminal navigation, automated demo mode, unit test runner,
SQLite indexed search with pagination, runtime logging, and async report generation.
"""

import sys
import os
import argparse
import unittest
from typing import List

from models import CodeRecord, AIImprovement
from validation import validate_string, validate_integer, validate_float, validate_choice
from engine import AICodeEngine
from persistence import PersistenceManager
from sqlite_db import SQLiteDatabase
from analytics import AnalyticsModule
from export import AsyncExporter
from logger_config import logger, LOG_FILE

# ANSI Color Codes
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_header():
    print(f"\n{CYAN}{BOLD}" + "=" * 76)
    print("      🤖  AI CODE EXPLANATION NOTEBOOK — LOCALIMPACT (v2.0.0 RELEASE)")
    print("          SQLite Indexed DB | Async Exporter | Automated Test Suite")
    print("=" * 76 + f"{RESET}\n")

def run_unit_tests():
    print(f"\n{YELLOW}{BOLD}[*] RUNNING AUTOMATED UNIT TEST SUITE...{RESET}\n")
    logger.info("CLI Menu invoked automated unit test suite.")
    tests_dir = os.path.join(os.path.dirname(__file__), "tests")
    suite = unittest.defaultTestLoader.discover(tests_dir, pattern="test_*.py")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    if result.wasSuccessful():
        print(f"\n{GREEN}{BOLD}✓ ALL UNIT TESTS PASSED SUCCESSFULLY! ({result.testsRun} tests run){RESET}")
    else:
        print(f"\n{RED}{BOLD}✘ SOME UNIT TESTS FAILED. ({len(result.failures)} failures, {len(result.errors)} errors){RESET}")

def view_records_paginated(db: SQLiteDatabase):
    print(f"\n{CYAN}{BOLD}--- RECORD QUERY & INDEXED PAGINATED SEARCH ---{RESET}")
    keyword = input("Enter search keyword (or press Enter for all): ").strip()
    language = input("Filter by language (e.g., Python, Go, Rust, or Enter for all): ").strip()
    status = input("Filter by status (Draft/Analyzed/Optimized, or Enter for all): ").strip()

    page = 1
    page_size = 5

    while True:
        res = db.query_records_paginated(
            keyword=keyword,
            language=language,
            status=status,
            page=page,
            page_size=page_size
        )

        print(f"\n{BOLD}Page {res.page} of {res.total_pages} (Total Records: {res.total_count}){RESET}")
        print("-" * 76)

        if not res.items:
            print(f"{YELLOW}No records found matching criteria.{RESET}")

        for r in res.items:
            print(
                f"• [{r.record_id}] {BOLD}{r.program_name}{RESET} ({r.language}) | "
                f"LOC: {r.lines_of_code} | Complexity: {r.cyclomatic_complexity} | "
                f"Status: {r.status} | AI Suggestions: {len(r.ai_improvements)}"
            )

        print("-" * 76)
        print("Nav: [N]ext Page | [P]revious Page | [V]iew Detail | [E]xit Search")
        choice = input("Choice: ").strip().lower()

        if choice == 'n':
            if page < res.total_pages:
                page += 1
            else:
                print(f"{YELLOW}You are already on the last page.{RESET}")
        elif choice == 'p':
            if page > 1:
                page -= 1
            else:
                print(f"{YELLOW}You are already on the first page.{RESET}")
        elif choice == 'v':
            rec_id = input("Enter Record ID to view details: ").strip()
            rec = db.get_record(rec_id)
            if rec:
                print(f"\n{GREEN}{BOLD}=== RECORD DETAILS: {rec.record_id} ==={RESET}")
                print(f"Program Name : {rec.program_name}")
                print(f"Language     : {rec.language}")
                print(f"LOC / Complex: {rec.lines_of_code} / {rec.cyclomatic_complexity}")
                print(f"Created At   : {rec.created_at}")
                print(f"AI Summary   : {rec.ai_summary}")
                print(f"{BOLD}AI Improvements ({len(rec.ai_improvements)}):{RESET}")
                for imp in rec.ai_improvements:
                    print(f"  • [{imp.impact_rating.upper()}] {imp.category}: {imp.title}")
                    print(f"    Description: {imp.description}")
                    print(f"    Original   : {imp.original_snippet}")
                    print(f"    Improved   : {imp.improved_snippet}")
            else:
                print(f"{RED}Record '{rec_id}' not found.{RESET}")
        elif choice == 'e':
            break

def view_logs():
    print(f"\n{CYAN}{BOLD}--- SYSTEM RUNTIME LOG MONITORING ---{RESET}")
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            lines = f.readlines()
        recent = lines[-25:]
        print(f"Showing last 25 lines of {LOG_FILE}:")
        print("-" * 76)
        for line in recent:
            print(line.strip())
        print("-" * 76)
    else:
        print(f"{YELLOW}Log file not found at {LOG_FILE}.{RESET}")

def run_hackathon_demo():
    print(f"\n{MAGENTA_OR_YELLOW if 'MAGENTA_OR_YELLOW' in globals() else YELLOW}{BOLD}=== RUNNING AUTOMATED DEMO JOURNEY (HACKATHON EVALUATION) ==={RESET}")
    db = SQLiteDatabase()
    pm = PersistenceManager(db)

    print("\n[*] 1. Initializing seed data and loading persistence...")
    import seed_data
    records = seed_data.generate_sample_dataset(35)
    pm.save_records(records)
    print(f"{GREEN}✓ Loaded & indexed {len(records)} records in SQLite DB.{RESET}")

    print("\n[*] 2. Analyzing snippet with AI Code Engine...")
    sample_code = "def fetch_users(ids):\n    for i in range(len(ids)):\n        f = open('users.txt', 'a')\n        f.write(str(ids[i]))\n        f.close()"
    new_rec = AICodeEngine.analyze_code("DemoWorkerModule", "Python", sample_code)
    pm.save_record(new_rec)
    print(f"{GREEN}✓ Created & saved new record {new_rec.record_id} with {len(new_rec.ai_improvements)} AI optimizations.{RESET}")

    print("\n[*] 3. Running Automated Unit Test Suite...")
    tests_dir = os.path.join(os.path.dirname(__file__), "tests")
    suite = unittest.defaultTestLoader.discover(tests_dir, pattern="test_*.py")
    runner = unittest.TextTestRunner(verbosity=0)
    res = runner.run(suite)
    print(f"{GREEN}✓ Executed {res.testsRun} unit tests successfully (0 failures).{RESET}")

    print("\n[*] 4. Computing Executive Analytics & Checking Threshold Warnings...")
    all_recs = pm.load_records()
    metrics = AnalyticsModule.compute_summary(all_recs)
    print(f"   • Total Records Indexed: {metrics.total_records}")
    print(f"   • Total Lines of Code  : {metrics.total_lines_of_code}")
    print(f"   • Avg Complexity Score : {metrics.avg_complexity} / 10.0")
    print(f"   • Active Warnings      : {len(metrics.threshold_warnings)}")
    for w in metrics.threshold_warnings[:3]:
        print(f"     {w}")

    print("\n[*] 5. Executing Multi-Threaded Async Report Exporter...")
    paths = AsyncExporter.export_all_async(all_recs)
    print(f"{GREEN}✓ Markdown Report : {paths['markdown']}{RESET}")
    print(f"{GREEN}✓ Audit Log File  : {paths['audit_log']}{RESET}")
    print(f"{GREEN}✓ Dashboard PNG   : {paths['dashboard']}{RESET}")

    print(f"\n{GREEN}{BOLD}=== DEMO JOURNEY COMPLETED SUCCESSFULLY! ==={RESET}\n")

def main():
    parser = argparse.ArgumentParser(description="AI Code Explanation Notebook (v2.0.0)")
    parser.add_argument("--demo", action="store_true", help="Run automated demo journey")
    parser.add_argument("--test", action="store_true", help="Run automated unit test suite")
    parser.add_argument("--export", action="store_true", help="Run async multi-format export")
    args = parser.parse_args()

    if args.demo:
        run_hackathon_demo()
        return

    if args.test:
        run_unit_tests()
        return

    db = SQLiteDatabase()
    pm = PersistenceManager(db)

    # Initial seed if empty
    if db.get_total_count() == 0:
        logger.info("Empty database detected on startup. Seeding sample dataset...")
        import seed_data
        recs = seed_data.generate_sample_dataset(35)
        pm.save_records(recs)

    if args.export:
        recs = pm.load_records()
        paths = AsyncExporter.export_all_async(recs)
        print(f"{GREEN}[+] Async export completed successfully:{RESET}")
        for k, v in paths.items():
            print(f"  - {k}: {v}")
        return

    while True:
        print_header()
        print(f"{BOLD}Main Options Menu:{RESET}")
        print("  1. 🔍 Query & Search Records (SQLite Indexed + Paginated)")
        print("  2. ⚡ Analyze New Code Snippet (AI Explanation Engine)")
        print("  3. 📊 View Executive Summary & Threshold Warnings")
        print("  4. 📤 Export Reports & Matplotlib Dashboard (Async Threaded)")
        print("  5. 🧪 Run Automated Unit Test Suite (pytest/unittest)")
        print("  6. 🚀 Run Hackathon Demo Journey (--demo)")
        print("  7. 📜 View System Runtime Logs (logs/app.log)")
        print("  8. ❌ Exit Application")

        choice = validate_choice("\nSelect an option", ["1", "2", "3", "4", "5", "6", "7", "8"])

        if choice == "1":
            view_records_paginated(db)
        elif choice == "2":
            print(f"\n{CYAN}{BOLD}--- ANALYZE NEW CODE PROGRAM ---{RESET}")
            prog_name = validate_string("Enter Program Name: ", min_len=2, max_len=80)
            lang = validate_choice("Select Programming Language", ["Python", "TypeScript", "Go", "Rust", "Java"])
            print("Enter/paste code snippet (end with empty line):")
            code_lines = []
            while True:
                line = input()
                if not line and code_lines:
                    break
                code_lines.append(line)
            code_text = "\n".join(code_lines)

            record = AICodeEngine.analyze_code(prog_name, lang, code_text)
            pm.save_record(record)
            print(f"\n{GREEN}{BOLD}✓ Code Analyzed & Persisted to SQLite/JSON/CSV!{RESET}")
            print(f"Record ID: {record.record_id} | Complexity: {record.cyclomatic_complexity}")
            print(f"AI Summary: {record.ai_summary}")
        elif choice == "3":
            recs = pm.load_records()
            metrics = AnalyticsModule.compute_summary(recs)
            print(f"\n{CYAN}{BOLD}=== EXECUTIVE METRICS SUMMARY ==={RESET}")
            print(f"Total Programs Indexed : {metrics.total_records}")
            print(f"Total Lines of Code    : {metrics.total_lines_of_code}")
            print(f"Avg Cyclomatic Score   : {metrics.avg_complexity} / 10.0")
            print(f"Avg Execution Time (ms): {metrics.avg_execution_time_ms} ms")
            print(f"\n{BOLD}Threshold Warning Flags ({len(metrics.threshold_warnings)}):{RESET}")
            for w in metrics.threshold_warnings[:5]:
                print(f"  {w}")
            input("\nPress Enter to return to main menu...")
        elif choice == "4":
            recs = pm.load_records()
            print(f"\n{YELLOW}[*] Spawning async exporter workers...{RESET}")
            paths = AsyncExporter.export_all_async(recs)
            print(f"{GREEN}{BOLD}✓ Async Export Complete!{RESET}")
            print(f"  • Markdown Report : {paths['markdown']}")
            print(f"  • Audit Log File  : {paths['audit_log']}")
            print(f"  • Dashboard Plot  : {paths['dashboard']}")
            input("\nPress Enter to return to main menu...")
        elif choice == "5":
            run_unit_tests()
            input("\nPress Enter to return to main menu...")
        elif choice == "6":
            run_hackathon_demo()
            input("\nPress Enter to return to main menu...")
        elif choice == "7":
            view_logs()
            input("\nPress Enter to return to main menu...")
        elif choice == "8":
            print(f"\n{CYAN}Thank you for using AI Code Explanation Notebook! Goodbye.{RESET}\n")
            sys.exit(0)

if __name__ == "__main__":
    main()
