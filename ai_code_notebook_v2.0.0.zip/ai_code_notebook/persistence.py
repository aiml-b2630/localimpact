"""
Local Persistence Manager (v2.0.0)
Provides thread-safe, atomic JSON & CSV file reading and writing with schema checks,
automatic recovery from corrupted files, and synchronization with SQLite database.
"""

import os
import json
import csv
import threading
from typing import List, Optional
from models import CodeRecord, AIImprovement
from sqlite_db import SQLiteDatabase
from logger_config import logger

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)
JSON_PATH = os.path.join(DATA_DIR, "sample_records.json")
CSV_PATH = os.path.join(DATA_DIR, "sample_records.csv")

class PersistenceManager:
    _file_lock = threading.Lock()

    def __init__(self, db: Optional[SQLiteDatabase] = None):
        self.db = db or SQLiteDatabase()

    def load_records(self) -> List[CodeRecord]:
        with self._file_lock:
            # Primary load from SQLite database for maximum reliability
            db_records = self.db.get_all_records()
            if db_records:
                logger.info(f"Loaded {len(db_records)} records from SQLite database.")
                return db_records

            # Fallback load from JSON file
            if os.path.exists(JSON_PATH):
                try:
                    with open(JSON_PATH, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        records = [CodeRecord.from_dict(d) for d in data]
                        logger.info(f"Loaded {len(records)} records from JSON file.")
                        # Sync to SQLite
                        self.db.save_records_batch(records)
                        return records
                except (json.JSONDecodeError, KeyError, Exception) as e:
                    logger.error(f"Error reading JSON file (corrupted or invalid): {e}. Initializing clean state.")

            # Fallback to empty list if no file/records found
            return []

    def save_records(self, records: List[CodeRecord]) -> bool:
        with self._file_lock:
            try:
                # 1. Save to SQLite database
                db_success = self.db.save_records_batch(records)

                # 2. Atomic Write to JSON file
                temp_json = JSON_PATH + ".tmp"
                dict_list = [r.to_dict() for r in records]
                with open(temp_json, "w", encoding="utf-8") as f:
                    json.dump(dict_list, f, indent=2, ensure_ascii=False)
                os.replace(temp_json, JSON_PATH)

                # 3. Atomic Write to CSV file
                temp_csv = CSV_PATH + ".tmp"
                with open(temp_csv, "w", encoding="utf-8", newline="") as f:
                    writer = csv.writer(f)
                    writer.writerow([
                        "record_id", "program_name", "language", "lines_of_code",
                        "cyclomatic_complexity", "status", "created_at",
                        "ai_summary", "execution_time_ms", "memory_mb", "improvements_count"
                    ])
                    for r in records:
                        writer.writerow([
                            r.record_id, r.program_name, r.language, r.lines_of_code,
                            r.cyclomatic_complexity, r.status, r.created_at,
                            r.ai_summary, r.execution_time_ms, r.memory_mb,
                            len(r.ai_improvements)
                        ])
                os.replace(temp_csv, CSV_PATH)

                logger.info(f"Successfully saved {len(records)} records across SQLite, JSON, and CSV.")
                return True
            except Exception as e:
                logger.error(f"Failed to save records: {e}")
                return False

    def save_record(self, record: CodeRecord) -> bool:
        current_records = self.load_records()
        # Update existing or append new
        updated = False
        for i, r in enumerate(current_records):
            if r.record_id == record.record_id:
                current_records[i] = record
                updated = True
                break
        if not updated:
            current_records.append(record)
        return self.save_records(current_records)
