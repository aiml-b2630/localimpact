# 🤖 AI Code Explanation Notebook (Release Package v1.0.0)

**Project #120: AI Code Explanation Notebook | Domain: AI, APIs & Smart Applications**

An integrated, accessible Python software application engineered to streamline data handling, validate entries, suggest/test/document code improvements using AI, and present actionable visual summaries.

---

## 🌟 Key Features

1. **Interactive Terminal Interface:** Menu-driven command prompt with ANSI formatting, clear prompt guides, and workflow execution.
2. **Defensive Input Validation:** Real-time sanitization, range checking, regex validation, and input loops preventing program crashes.
3. **Core Business Logic Engine:** AI suggestion generator, static code analysis simulator, and automated test execution.
4. **Local Data Persistence (CSV & JSON):** Dual-format reading/writing with corruption detection and clean template auto-recovery.
5. **Record Query & Search:** Keyword, tag, status, and category filtering tools.
6. **Executive Summary Aggregation:** Calculates totals, averages, status breakdowns, and flags.
7. **Visual Data Plotting:** Matplotlib integration generating 2x2 visual dashboard charts (`reports/analytics_dashboard.png`).
8. **Multi-Format Summary Export:** Standardized Markdown (`reports/executive_summary.md`), audit log text (`reports/audit_log.txt`), and CSV exports.
9. **Threshold Warning Flags:** Console alerts highlighting high-complexity routines (>7.0 cyclomatic score) or large file sizes.

---

## 📁 Repository Structure

```
ai_code_notebook/
├── README.md                 # Project Overview & Usage Guide
├── requirements.txt           # Package Dependencies
├── main.py                    # Main Console Menu & CLI Dispatcher
├── models.py                  # Dataclasses & Schema Definitions
├── validation.py              # Defensive Input Validation Wrappers
├── engine.py                  # Core AI Analysis & Testing Engine
├── persistence.py             # JSON/CSV Read & Write Storage Handlers
├── analytics.py               # Summary Metrics & Threshold Warnings
├── plotting.py                # Matplotlib Dashboard Visualization
├── export.py                  # Markdown & Audit Log Report Exporters
├── seed_data.py               # Sample Dataset Generator (35 records)
└── data/
    ├── sample_records.json    # 35 Pre-seeded JSON Test Cases
    └── sample_records.csv     # 35 Pre-seeded CSV Test Cases
```

---

## 🚀 Quick Start Guide

### 1. Requirements & Setup
- Python 3.10 or higher
- Install dependencies:
  ```bash
  pip install -r requirements.txt
  ```

### 2. Running the Application

- **Interactive Menu Mode:**
  ```bash
  python3 main.py
  ```

- **Automated Demo Journey (Hackathon Mode):**
  ```bash
  python3 main.py --demo
  ```

- **Direct Export Mode (Reports & Charts):**
  ```bash
  python3 main.py --export
  ```

---

## 📊 Sample Demo Journey Output

Running `python3 main.py --demo` performs:
1. Loading 35 pre-seeded records from JSON persistence.
2. Running AI code analysis and generating test suggestions.
3. Computing metrics and detecting high-complexity threshold warnings.
4. Exporting `reports/analytics_dashboard.png` via Matplotlib.
5. Exporting `reports/executive_summary.md` and `reports/audit_log.txt`.

---

*Delivered as part of LocalImpact Challenge Hackathon Project #120.*
