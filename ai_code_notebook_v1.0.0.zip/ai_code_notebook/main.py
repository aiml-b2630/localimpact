"""
AI Code Explanation Notebook - Main Application Console & Dispatcher Loop.
Project #120: AI Code Explanation Notebook | Domain: AI, APIs & Smart Applications
"""
import sys
import os
import argparse
from datetime import datetime

# Local imports
from models import CodeRecord, AIImprovement
from validation import validate_string, validate_integer, validate_float, validate_choice
from engine import AICodeEngine
from persistence import DataPersistenceManager
from analytics import AnalyticsEngine
from plotting import ChartGenerator
from export import ReportExportManager

# ANSI Color formatting codes
HEADER = '\033[95m'
BLUE = '\033[94m'
GREEN = '\033[92m'
WARNING = '\033[93m'
FAIL = '\033[91m'
ENDC = '\033[0m'
BOLD = '\033[1m'

def print_banner():
    """Display branded ASCII welcome banner."""
    print(f"{BLUE}{BOLD}")
    print("================================================================================")
    print("     🤖 AI CODE EXPLANATION NOTEBOOK - HACKATHON RELEASE v1.0.0 🤖              ")
    print("     Domain: AI, APIs & Smart Applications | Project #120                        ")
    print("================================================================================")
    print(f"{ENDC}")

def display_menu():
    """Display interactive main menu options."""
    print(f"\n{BOLD}MAIN MENU OPTIONS:{ENDC}")
    print(f"  {GREEN}[1]{ENDC} Add New Code Record & Run AI Analysis")
    print(f"  {GREEN}[2]{ENDC} View All Records & Filter Registry")
    print(f"  {GREEN}[3]{ENDC} Run Executive Analytics & View Summary Metrics")
    print(f"  {GREEN}[4]{ENDC} Generate & Export Matplotlib Visual Charts")
    print(f"  {GREEN}[5]{ENDC} Export Reports (Markdown & Audit Log)")
    print(f"  {GREEN}[6]{ENDC} Check Threshold Warnings & System Flags")
    print(f"  {GREEN}[7]{ENDC} Load Sample Hackathon Dataset (35 Records)")
    print(f"  {GREEN}[8]{ENDC} Run Automated End-to-End Demo Journey")
    print(f"  {FAIL}[0]{ENDC} Save & Exit Application")

def run_demo_mode(persistence: DataPersistenceManager):
    """Execute end-to-end automated demo journey showcasing all application capabilities."""
    print(f"\n{HEADER}{BOLD}=== RUNNING AUTOMATED DEMO JOURNEY ==={ENDC}")
    
    # 1. Load sample dataset
    print("[*] 1. Loading sample hackathon dataset...")
    records = persistence.load_from_json()
    if not records:
        print("[!] No records found. Generating initial seed dataset...")
        os.system("python3 seed_data.py")
        records = persistence.load_from_json()

    print(f"{GREEN}✓ Loaded {len(records)} records from JSON persistence.{ENDC}")

    # 2. Simulate AI Analysis on new code snippet
    print("\n[*] 2. Analyzing snippet with AI Code Engine...")
    sample_code = "def calculate_totals(items):\n    total = 0\n    for i in range(len(items)):\n        total += items[i]\n    return total"
    
    analysis = AICodeEngine.analyze_code_snippet(sample_code)
    new_rec = CodeRecord(
        record_id=f"REC-{len(records) + 1001}",
        project_name="DemoPaymentGateway",
        author="Hackathon Presenter",
        timestamp=datetime.now().isoformat(),
        language="Python",
        lines_of_code=analysis["lines_of_code"],
        complexity_score=analysis["complexity_score"],
        status="In Testing",
        tags=["demo", "payment", "ai-suggested"]
    )
    
    suggestions = AICodeEngine.generate_ai_suggestions(new_rec, sample_code)
    for sug in suggestions:
        test_res = AICodeEngine.simulate_test_suite(sug)
        new_rec.improvements.append(sug.to_dict() if hasattr(sug, 'to_dict') else sug.__dict__)

    records.append(new_rec)
    persistence.save_to_json(records)
    persistence.save_to_csv(records)
    print(f"{GREEN}✓ Successfully created persistent record {new_rec.record_id} with {len(suggestions)} AI suggestions.{ENDC}")

    # 3. Analytics & Thresholds
    print("\n[*] 3. Computing Executive Metrics & Checking Warnings...")
    metrics = AnalyticsEngine.compute_metrics(records)
    print(f"   • Total Records: {metrics.total_records}")
    print(f"   • Total LOC: {metrics.total_lines_of_code}")
    print(f"   • Avg Complexity: {metrics.avg_complexity} / 10.0")
    
    warnings = AnalyticsEngine.check_threshold_warnings(records)
    print(f"   • Threshold Warnings Triggered: {len(warnings)}")
    for w in warnings[:3]:
        print(f"     {w}")

    # 4. Generate Visual Chart
    print("\n[*] 4. Exporting Matplotlib Analytics Dashboard...")
    chart_path = ChartGenerator.plot_summary_dashboard(records, "reports/analytics_dashboard.png")
    print(f"{GREEN}✓ Dashboard saved to: {chart_path}{ENDC}")

    # 5. Export Markdown & Audit Log
    print("\n[*] 5. Exporting Markdown Report & Audit Log...")
    md_path = ReportExportManager.export_markdown_report(records, "reports/executive_summary.md")
    log_path = ReportExportManager.export_audit_log(records, "reports/audit_log.txt")
    print(f"{GREEN}✓ Markdown Report: {md_path}{ENDC}")
    print(f"{GREEN}✓ Audit Log: {log_path}{ENDC}")
    
    print(f"\n{GREEN}{BOLD}=== DEMO JOURNEY COMPLETED SUCCESSFULLY! ==={ENDC}\n")

def main():
    parser = argparse.ArgumentParser(description="AI Code Explanation Notebook CLI")
    parser.add_argument("--demo", action="store_true", help="Run automated end-to-end demo mode")
    parser.add_argument("--export", action="store_true", help="Export summary reports and charts directly")
    args = parser.parse_args()

    persistence = DataPersistenceManager(
        json_path="data/sample_records.json",
        csv_path="data/sample_records.csv"
    )

    if args.demo:
        run_demo_mode(persistence)
        return

    records = persistence.load_from_json()
    if not records:
        records = persistence.load_from_csv()

    if args.export:
        ChartGenerator.plot_summary_dashboard(records, "reports/analytics_dashboard.png")
        ReportExportManager.export_markdown_report(records, "reports/executive_summary.md")
        ReportExportManager.export_audit_log(records, "reports/audit_log.txt")
        print("[+] Direct export finished successfully.")
        return

    print_banner()

    while True:
        display_menu()
        choice = input("\nSelect option [0-8]: ").strip()

        if choice == "1":
            print(f"\n{BOLD}--- ADD NEW CODE RECORD ---{ENDC}")
            proj_name = validate_string("Enter Project Name: ", min_len=2)
            author = validate_string("Enter Author Name: ", min_len=2)
            loc = validate_integer("Enter Lines of Code (LOC): ", min_val=1, max_val=10000)
            comp = validate_float("Enter Cyclomatic Complexity (1.0 - 10.0): ", min_val=1.0, max_val=10.0)
            status = validate_choice("Select Initial Status", ["Pending Review", "In Testing", "Documented", "Completed"])
            
            rec_id = f"REC-{len(records) + 1001}"
            new_rec = CodeRecord(
                record_id=rec_id,
                project_name=proj_name,
                author=author,
                timestamp=datetime.now().isoformat(),
                language="Python",
                lines_of_code=loc,
                complexity_score=comp,
                status=status,
                tags=["manual-entry"]
            )
            
            print("\n[*] Running AI Code Analysis Engine...")
            mock_snippet = f"def {proj_name.lower()}():\n    for i in range({loc}): pass"
            sugs = AICodeEngine.generate_ai_suggestions(new_rec, mock_snippet)
            for s in sugs:
                new_rec.improvements.append(s.__dict__)
            
            records.append(new_rec)
            persistence.save_to_json(records)
            persistence.save_to_csv(records)
            print(f"{GREEN}✓ Saved record {rec_id} with {len(sugs)} AI suggestions.{ENDC}")

        elif choice == "2":
            print(f"\n{BOLD}--- CODE RECORDS REGISTRY ({len(records)} Records) ---{ENDC}")
            kw = input("Enter search keyword/tag (press Enter for all): ").strip()
            filtered = AnalyticsEngine.filter_records(records, keyword=kw)
            print("-" * 85)
            print(f"{'ID':<10} | {'Project Name':<22} | {'Author':<15} | {'LOC':<6} | {'Comp':<5} | {'Status':<14}")
            print("-" * 85)
            for r in filtered[:15]:
                print(f"{r.record_id:<10} | {r.project_name[:22]:<22} | {r.author[:15]:<15} | {r.lines_of_code:<6} | {r.complexity_score:<5} | {r.status:<14}")
            if len(filtered) > 15:
                print(f"... and {len(filtered) - 15} more records.")
            print("-" * 85)

        elif choice == "3":
            print(f"\n{BOLD}--- EXECUTIVE SUMMARY METRICS ---{ENDC}")
            m = AnalyticsEngine.compute_metrics(records)
            print(f"  • Total Records Analyzed:        {m.total_records}")
            print(f"  • Total Lines of Code (LOC):     {m.total_lines_of_code}")
            print(f"  • Average Cyclomatic Complexity: {m.avg_complexity} / 10.0")
            print(f"  • Total AI Suggestions:          {m.total_improvements}")
            print(f"  • High-Complexity Flagged Records: {m.high_complexity_flag_count}")
            print("\n  Status Breakdown:")
            for s, c in m.status_counts.items():
                print(f"    - {s}: {c}")

        elif choice == "4":
            print(f"\n{BOLD}--- GENERATING MATPLOTLIB VISUAL CHARTS ---{ENDC}")
            path = ChartGenerator.plot_summary_dashboard(records, "reports/analytics_dashboard.png")
            print(f"{GREEN}✓ Visual analytics dashboard exported to: {path}{ENDC}")

        elif choice == "5":
            print(f"\n{BOLD}--- EXPORTING MULTI-FORMAT REPORTS ---{ENDC}")
            md = ReportExportManager.export_markdown_report(records, "reports/executive_summary.md")
            log = ReportExportManager.export_audit_log(records, "reports/audit_log.txt")
            print(f"{GREEN}✓ Markdown Report: {md}{ENDC}")
            print(f"{GREEN}✓ Plain-Text Audit Log: {log}{ENDC}")

        elif choice == "6":
            print(f"\n{BOLD}--- THRESHOLD WARNINGS & SYSTEM FLAGS ---{ENDC}")
            warns = AnalyticsEngine.check_threshold_warnings(records)
            if warns:
                for w in warns:
                    print(f"  {WARNING}{w}{ENDC}")
            else:
                print(f"{GREEN}✓ All records within normal complexity and size boundaries.{ENDC}")

        elif choice == "7":
            print("\n[*] Reloading seed dataset (35 sample records)...")
            os.system("python3 seed_data.py")
            records = persistence.load_from_json()
            print(f"{GREEN}✓ Dataset reloaded: {len(records)} records active.{ENDC}")

        elif choice == "8":
            run_demo_mode(persistence)

        elif choice == "0":
            print("\n[*] Saving state to persistent storage...")
            persistence.save_to_json(records)
            persistence.save_to_csv(records)
            print(f"{GREEN}✓ State saved. Thank you for using AI Code Explanation Notebook! Goodbye.{ENDC}\n")
            break
        else:
            print(f"{FAIL}[!] Invalid option. Please select a number between 0 and 8.{ENDC}")

if __name__ == "__main__":
    main()
