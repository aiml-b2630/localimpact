"""
Local Data Persistence Module supporting JSON and CSV formats with schema verification and auto-recovery.
"""
import os
import json
import csv
from typing import List, Dict, Any
from models import CodeRecord

class DataPersistenceManager:
    """Handles auto-reading and writing of structured records to JSON/CSV files with corruption recovery."""

    def __init__(self, json_path: str = "data/records.json", csv_path: str = "data/records.csv"):
        self.json_path = json_path
        self.csv_path = csv_path

    def save_to_json(self, records: List[CodeRecord]) -> bool:
        """Save list of CodeRecord instances to structured JSON."""
        try:
            os.makedirs(os.path.dirname(self.json_path), exist_ok=True)
            data = [r.to_dict() for r in records]
            with open(self.json_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"[!] Error writing JSON storage: {e}")
            return False

    def load_from_json(self) -> List[CodeRecord]:
        """Load CodeRecord instances from JSON with schema validation and fallback."""
        if not os.path.exists(self.json_path):
            return []
        try:
            with open(self.json_path, 'r', encoding='utf-8') as f:
                raw_list = json.load(f)
            if not isinstance(raw_list, list):
                raise ValueError("JSON root element must be a list of records.")
            return [CodeRecord.from_dict(item) for item in raw_list]
        except (json.JSONDecodeError, ValueError) as e:
            print(f"[!] Corrupted/invalid JSON detected at {self.json_path}: {e}")
            print("[*] Initializing clean template fallback...")
            return []

    def save_to_csv(self, records: List[CodeRecord]) -> bool:
        """Export CodeRecords to CSV format."""
        try:
            os.makedirs(os.path.dirname(self.csv_path), exist_ok=True)
            fieldnames = ["record_id", "project_name", "author", "timestamp", "language",
                          "lines_of_code", "complexity_score", "status", "num_improvements", "tags", "notes"]
            with open(self.csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for r in records:
                    writer.writerow({
                        "record_id": r.record_id,
                        "project_name": r.project_name,
                        "author": r.author,
                        "timestamp": r.timestamp,
                        "language": r.language,
                        "lines_of_code": r.lines_of_code,
                        "complexity_score": r.complexity_score,
                        "status": r.status,
                        "num_improvements": len(r.improvements),
                        "tags": ";".join(r.tags),
                        "notes": r.notes
                    })
            return True
        except Exception as e:
            print(f"[!] Error writing CSV file: {e}")
            return False

    def load_from_csv(self) -> List[CodeRecord]:
        """Load basic records from CSV file."""
        if not os.path.exists(self.csv_path):
            return []
        records = []
        try:
            with open(self.csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    records.append(CodeRecord(
                        record_id=row.get("record_id", ""),
                        project_name=row.get("project_name", "Untitled"),
                        author=row.get("author", "Anonymous"),
                        timestamp=row.get("timestamp", ""),
                        language=row.get("language", "Python"),
                        lines_of_code=int(row.get("lines_of_code", 0)),
                        complexity_score=float(row.get("complexity_score", 1.0)),
                        status=row.get("status", "Pending Review"),
                        improvements=[],
                        tags=row.get("tags", "").split(";") if row.get("tags") else [],
                        notes=row.get("notes", "")
                    ))
            return records
        except Exception as e:
            print(f"[!] Error reading CSV file: {e}")
            return []
