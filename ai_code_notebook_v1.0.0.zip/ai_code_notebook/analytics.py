"""
Aggregation and analytics calculation engine with threshold warning indicators.
"""
from typing import List, Dict, Any
from models import CodeRecord, SummaryMetrics

class AnalyticsEngine:
    """Computes summary metrics, trends, and automated warning indicators."""

    HIGH_COMPLEXITY_THRESHOLD = 7.0
    LARGE_LOC_THRESHOLD = 500

    @classmethod
    def compute_metrics(cls, records: List[CodeRecord]) -> SummaryMetrics:
        """Aggregate total counts, averages, status distributions, and flags."""
        if not records:
            return SummaryMetrics(
                total_records=0,
                total_lines_of_code=0,
                avg_complexity=0.0,
                total_improvements=0,
                status_counts={},
                improvement_categories={},
                high_complexity_flag_count=0
            )

        total_records = len(records)
        total_loc = sum(r.lines_of_code for r in records)
        avg_complexity = round(sum(r.complexity_score for r in records) / total_records, 2)
        total_improvements = sum(len(r.improvements) for r in records)

        status_counts: Dict[str, int] = {}
        for r in records:
            status_counts[r.status] = status_counts.get(r.status, 0) + 1

        cat_counts: Dict[str, int] = {}
        high_complexity_count = 0

        for r in records:
            if r.complexity_score >= cls.HIGH_COMPLEXITY_THRESHOLD:
                high_complexity_count += 1
            for imp in r.improvements:
                cat = imp.get("category", "General") if isinstance(imp, dict) else imp.category
                cat_counts[cat] = cat_counts.get(cat, 0) + 1

        return SummaryMetrics(
            total_records=total_records,
            total_lines_of_code=total_loc,
            avg_complexity=avg_complexity,
            total_improvements=total_improvements,
            status_counts=status_counts,
            improvement_categories=cat_counts,
            high_complexity_flag_count=high_complexity_count
        )

    @classmethod
    def check_threshold_warnings(cls, records: List[CodeRecord]) -> List[str]:
        """Generate console warning messages for anomalous or threshold-exceeding records."""
        warnings = []
        for r in records:
            if r.complexity_score >= cls.HIGH_COMPLEXITY_THRESHOLD:
                warnings.append(f"⚠️ [HIGH COMPLEXITY] {r.record_id} ({r.project_name}): Cyclomatic score {r.complexity_score} exceeds threshold ({cls.HIGH_COMPLEXITY_THRESHOLD}).")
            if r.lines_of_code >= cls.LARGE_LOC_THRESHOLD:
                warnings.append(f"⚠️ [LARGE FILE] {r.record_id} ({r.project_name}): {r.lines_of_code} LOC requires module decomposition.")
            if r.status == "Pending Review" and len(r.improvements) == 0:
                warnings.append(f"⚠️ [UNANALYZED] {r.record_id} ({r.project_name}): Record pending review with 0 AI suggestions generated.")
        return warnings

    @classmethod
    def filter_records(cls, records: List[CodeRecord], keyword: str = "", category: str = "", status: str = "") -> List[CodeRecord]:
        """Filter records by keyword, tag, category, or status."""
        results = records
        if keyword:
            kw = keyword.lower()
            results = [r for r in results if kw in r.project_name.lower() or kw in r.author.lower() or any(kw in t.lower() for t in r.tags)]
        if status:
            results = [r for r in results if r.status.lower() == status.lower()]
        if category:
            filtered = []
            for r in results:
                for imp in r.improvements:
                    cat = imp.get("category", "") if isinstance(imp, dict) else imp.category
                    if cat.lower() == category.lower():
                        filtered.append(r)
                        break
            results = filtered
        return results
