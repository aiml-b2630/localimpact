"""
Core Business Logic Engine for AI Code Suggestion, Testing, and Documentation.
"""
import random
import time
from datetime import datetime
from typing import Dict, Any, List
from models import CodeRecord, AIImprovement

class AICodeEngine:
    """Core computational logic engine to analyze, suggest, test, and document code improvements."""

    CATEGORIES = ["Performance", "Security", "Readability", "BugFix", "Refactoring"]

    @staticmethod
    def analyze_code_snippet(snippet: str) -> Dict[str, Any]:
        """Perform simulated static analysis and metrics extraction on Python code."""
        lines = snippet.strip().split('\n')
        loc = len([l for l in lines if l.strip() and not l.strip().startswith('#')])
        num_loops = sum(1 for l in lines if 'for ' in l or 'while ' in l)
        num_conditionals = sum(1 for l in lines if 'if ' in l or 'elif ' in l)
        
        # Calculate mock cyclomatic complexity
        complexity = 1.0 + (num_loops * 1.5) + (num_conditionals * 1.0)
        complexity = min(10.0, max(1.0, round(complexity, 2)))
        
        return {
            "lines_of_code": loc,
            "complexity_score": complexity,
            "loops_count": num_loops,
            "conditionals_count": num_conditionals
        }

    @staticmethod
    def generate_ai_suggestions(record: CodeRecord, code_snippet: str) -> List[AIImprovement]:
        """Generate structured AI suggestions for code improvements."""
        suggestions = []
        lines = code_snippet.strip().split('\n')
        
        # Rule 1: Performance check
        if any('for ' in l for l in lines) and any('range(len(' in l for l in lines):
            suggestions.append(AIImprovement(
                suggestion_id=f"SUG-{random.randint(100, 999)}",
                category="Performance",
                description="Replace index-based loop over range(len(...)) with direct enumeration using enumerate() or direct iteration.",
                original_code_snippet="for i in range(len(items)): val = items[i]",
                improved_code_snippet="for i, val in enumerate(items): pass",
                status="Suggested",
                confidence_score=0.92
            ))

        # Rule 2: Exception handling / Security
        if not any('try:' in l for l in lines) and any('open(' in l or 'int(' in l for l in lines):
            suggestions.append(AIImprovement(
                suggestion_id=f"SUG-{random.randint(100, 999)}",
                category="Security",
                description="Add defensive try-except blocks around file/conversion ops to prevent unhandled runtime exceptions.",
                original_code_snippet="f = open(file_path); data = json.load(f)",
                improved_code_snippet="with open(file_path, 'r') as f:\n    data = json.load(f)",
                status="Suggested",
                confidence_score=0.95
            ))

        # Rule 3: Readability & type hints
        if not any('def ' in l and '->' in l for l in lines):
            suggestions.append(AIImprovement(
                suggestion_id=f"SUG-{random.randint(100, 999)}",
                category="Readability",
                description="Incorporate explicit Python type hints and docstrings for improved IDE autocompletion and maintainability.",
                original_code_snippet="def process_data(items, threshold):",
                improved_code_snippet="def process_data(items: list[int], threshold: float) -> list[int]:\n    \"\"\"Process entries meeting threshold criteria.\"\"\"",
                status="Suggested",
                confidence_score=0.88
            ))

        # Default fallback suggestion if snippet is short
        if not suggestions:
            suggestions.append(AIImprovement(
                suggestion_id=f"SUG-{random.randint(100, 999)}",
                category="Refactoring",
                description="Extract magic numbers and inline constants into centralized configuration dataclass.",
                original_code_snippet="if score > 75.5:",
                improved_code_snippet="THRESHOLD_SCORE = 75.5\nif score > THRESHOLD_SCORE:",
                status="Suggested",
                confidence_score=0.85
            ))
            
        return suggestions

    @staticmethod
    def simulate_test_suite(improvement: AIImprovement) -> Dict[str, Any]:
        """Simulate automated test execution for suggested code changes."""
        # Simulated test results
        passed = random.choice([True, True, True, False]) if improvement.confidence_score < 0.85 else True
        execution_time_ms = round(random.uniform(1.2, 18.5), 2)
        memory_usage_mb = round(random.uniform(4.5, 12.0), 2)
        
        status = "Approved" if passed else "Rejected"
        improvement.status = status
        
        return {
            "passed": passed,
            "execution_time_ms": execution_time_ms,
            "memory_usage_mb": memory_usage_mb,
            "test_timestamp": datetime.now().isoformat(),
            "status": status
        }
