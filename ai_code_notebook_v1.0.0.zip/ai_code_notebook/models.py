"""
Data models for AI Code Explanation Notebook.
"""
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import List, Optional, Dict, Any

@dataclass
class AIImprovement:
    suggestion_id: str
    category: str  # Performance, Security, Readability, BugFix, Refactoring
    description: str
    original_code_snippet: str
    improved_code_snippet: str
    status: str  # Suggested, Tested, Approved, Rejected, Documented
    confidence_score: float  # 0.0 to 1.0

@dataclass
class CodeRecord:
    record_id: str
    project_name: str
    author: str
    timestamp: str
    language: str
    lines_of_code: int
    complexity_score: float  # Cyclomatic complexity score 1.0 - 10.0
    status: str  # Pending Review, In Testing, Documented, Completed
    improvements: List[Dict[str, Any]] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CodeRecord':
        return cls(
            record_id=data.get("record_id", ""),
            project_name=data.get("project_name", "Untitled"),
            author=data.get("author", "Anonymous"),
            timestamp=data.get("timestamp", datetime.now().isoformat()),
            language=data.get("language", "Python"),
            lines_of_code=int(data.get("lines_of_code", 0)),
            complexity_score=float(data.get("complexity_score", 1.0)),
            status=data.get("status", "Pending Review"),
            improvements=data.get("improvements", []),
            tags=data.get("tags", []),
            notes=data.get("notes", "")
        )

@dataclass
class SummaryMetrics:
    total_records: int
    total_lines_of_code: int
    avg_complexity: float
    total_improvements: int
    status_counts: Dict[str, int]
    improvement_categories: Dict[str, int]
    high_complexity_flag_count: int
