"""
Multi-Format Summary Export module (Markdown, plain-text audit log, CSV).
"""
import os
import csv
from datetime import datetime
from typing import List
from models import CodeRecord
from analytics import AnalyticsEngine

class ReportExportManager:
    """Handles multi-format summary export generation."""

    @staticmethod
    def export_markdown_report(records: List[CodeRecord], output_path: str = "reports/executive_summary.md") -> str:
        """Export comprehensive Markdown summary report."""
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        metrics = AnalyticsEngine.compute_metrics(records)
        warnings = AnalyticsEngine.check_threshold_warnings(records)

        lines = [
            "# AI Code Explanation Notebook - Executive Summary",
            f"**Generated On:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## 1. Key Metrics Overview",
            f"- **Total Code Records Analyzed:** {metrics.total_records}",
            f"- **Total Lines of Code (LOC):** {metrics.total_lines_of_code}",
            f"- **Average Cyclomatic Complexity:** {metrics.avg_complexity} / 10.0",
            f"- **Total AI Suggestions Generated:** {metrics.total_improvements}",
            f"- **High-Complexity Flagged Records (Score >= 7.0):** {metrics.high_complexity_flag_count}",
            "",
            "## 2. Status Breakdown",
        ]
        for status, count in metrics.status_counts.items():
            lines.append(f"- **{status}:** {count} records")

        lines.extend([
            "",
            "## 3. Threshold Warnings & Flags",
        ])
        if warnings:
            for w in warnings:
                lines.append(f"- {w}")
        else:
            lines.append("No active threshold warnings.")

        lines.extend([
            "",
            "## 4. Code Records Registry",
            "| Record ID | Project Name | Author | LOC | Complexity | Status | AI Suggestions |",
            "| --- | --- | --- | --- | --- | --- | --- |"
        ])

        for r in records:
            lines.append(f"| `{r.record_id}` | {r.project_name} | {r.author} | {r.lines_of_code} | {r.complexity_score} | {r.status} | {len(r.improvements)} |")

        lines.append("")
        content = "\n".join(lines)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)

        return output_path

    @staticmethod
    def export_audit_log(records: List[CodeRecord], output_path: str = "reports/audit_log.txt") -> str:
        """Export plain-text detailed audit log for compliance and review."""
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        lines = [
            "================================================================================",
            "                   AI CODE EXPLANATION NOTEBOOK - AUDIT LOG                     ",
            f"Generated: {datetime.now().isoformat()}",
            "================================================================================",
            ""
        ]

        for r in records:
            lines.append(f"RECORD ID: {r.record_id} | PROJECT: {r.project_name} | AUTHOR: {r.author}")
            lines.append(f"Timestamp: {r.timestamp} | Language: {r.language} | LOC: {r.lines_of_code} | Complexity: {r.complexity_score}")
            lines.append(f"Status: {r.status} | Tags: {', '.join(r.tags)}")
            lines.append(f"Notes: {r.notes}")
            if r.improvements:
                lines.append("  AI Improvements:")
                for imp in r.improvements:
                    if isinstance(imp, dict):
                        lines.append(f"    - [{imp.get('suggestion_id')}] ({imp.get('category')}) {imp.get('description')} [Status: {imp.get('status')}]")
                    else:
                        lines.append(f"    - [{imp.suggestion_id}] ({imp.category}) {imp.description} [Status: {imp.status}]")
            lines.append("-" * 80)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        return output_path
