"""
Matplotlib visual data plotting integration for analytics trends and distributions.
"""
import os
from typing import List
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from models import CodeRecord
from analytics import AnalyticsEngine

class ChartGenerator:
    """Generates visual data plots for reports and metrics dashboard."""

    @staticmethod
    def plot_summary_dashboard(records: List[CodeRecord], output_path: str = "reports/analytics_dashboard.png") -> str:
        """Generate a 2x2 multi-panel matplotlib chart visualization."""
        if not records:
            return ""

        metrics = AnalyticsEngine.compute_metrics(records)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        fig, axs = plt.subplots(2, 2, figsize=(12, 10))
        fig.suptitle("AI Code Explanation Notebook - Visual Analytics Dashboard", fontsize=16, fontweight='bold')

        # 1. Status Breakdown (Pie Chart)
        statuses = list(metrics.status_counts.keys())
        counts = list(metrics.status_counts.values())
        colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#3BCEAC']
        axs[0, 0].pie(counts, labels=statuses, autopct='%1.1f%%', startangle=140, colors=colors[:len(statuses)])
        axs[0, 0].set_title("Records Status Breakdown", fontsize=12, fontweight='bold')

        # 2. Complexity Distribution (Histogram)
        complexities = [r.complexity_score for r in records]
        axs[0, 1].hist(complexities, bins=8, color='#2E86AB', edgecolor='black', alpha=0.7)
        axs[0, 1].axvline(AnalyticsEngine.HIGH_COMPLEXITY_THRESHOLD, color='red', linestyle='--', label=f'High Complexity Threshold ({AnalyticsEngine.HIGH_COMPLEXITY_THRESHOLD})')
        axs[0, 1].set_title("Cyclomatic Complexity Distribution", fontsize=12, fontweight='bold')
        axs[0, 1].set_xlabel("Complexity Score")
        axs[0, 1].set_ylabel("Frequency")
        axs[0, 1].legend()

        # 3. LOC vs Complexity Scatter Plot
        locs = [r.lines_of_code for r in records]
        axs[1, 0].scatter(locs, complexities, color='#A23B72', alpha=0.8, s=60)
        axs[1, 0].set_title("Lines of Code vs Cyclomatic Complexity", fontsize=12, fontweight='bold')
        axs[1, 0].set_xlabel("Lines of Code (LOC)")
        axs[1, 0].set_ylabel("Complexity Score")
        axs[1, 0].grid(True, linestyle=':', alpha=0.6)

        # 4. Improvement Categories (Bar Chart)
        if metrics.improvement_categories:
            cats = list(metrics.improvement_categories.keys())
            cat_counts = list(metrics.improvement_categories.values())
            axs[1, 1].bar(cats, cat_counts, color='#F18F01', edgecolor='black', alpha=0.85)
            axs[1, 1].set_title("AI Suggestions by Category", fontsize=12, fontweight='bold')
            axs[1, 1].set_xlabel("Category")
            axs[1, 1].set_ylabel("Count")
            plt.setp(axs[1, 1].get_xticklabels(), rotation=30, ha='right')
        else:
            axs[1, 1].text(0.5, 0.5, "No AI suggestions recorded yet", ha='center', va='center')
            axs[1, 1].set_title("AI Suggestions by Category", fontsize=12, fontweight='bold')

        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.savefig(output_path, dpi=200, bbox_inches='tight')
        plt.close()

        return output_path
