"""
Defensive input validation routines.
"""
import re
from typing import Optional

def sanitize_string(text: str) -> str:
    """Sanitize user text input by removing unwanted control characters."""
    if not text:
        return ""
    clean = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', text)
    return clean.strip()

def validate_integer(prompt: str, min_val: int = 0, max_val: int = 1000000) -> int:
    """Prompt until a valid integer within [min_val, max_val] is provided."""
    while True:
        raw = input(prompt).strip()
        try:
            val = int(raw)
            if min_val <= val <= max_val:
                return val
            print(f"[!] Input out of range ({min_val} - {max_val}). Please try again.")
        except ValueError:
            print("[!] Invalid integer format. Please enter a valid whole number.")

def validate_float(prompt: str, min_val: float = 0.0, max_val: float = 100.0) -> float:
    """Prompt until a valid float within [min_val, max_val] is provided."""
    while True:
        raw = input(prompt).strip()
        try:
            val = float(raw)
            if min_val <= val <= max_val:
                return round(val, 2)
            print(f"[!] Input out of range ({min_val} - {max_val}). Please try again.")
        except ValueError:
            print("[!] Invalid float format. Please enter a valid decimal number.")

def validate_string(prompt: str, min_len: int = 1, max_len: int = 200, pattern: Optional[str] = None) -> str:
    """Prompt until a non-empty string matching rules is entered."""
    while True:
        raw = sanitize_string(input(prompt))
        if len(raw) < min_len:
            print(f"[!] String too short (minimum {min_len} characters).")
            continue
        if len(raw) > max_len:
            print(f"[!] String too long (maximum {max_len} characters).")
            continue
        if pattern and not re.match(pattern, raw):
            print("[!] Input format does not match required pattern.")
            continue
        return raw

def validate_choice(prompt: str, choices: list) -> str:
    """Prompt user to select from a list of valid choices."""
    choices_str = "/".join([str(c) for c in choices])
    while True:
        raw = sanitize_string(input(f"{prompt} ({choices_str}): ")).strip()
        for c in choices:
            if str(c).lower() == raw.lower():
                return str(c)
        print(f"[!] Invalid selection. Please choose one of: {choices_str}")
